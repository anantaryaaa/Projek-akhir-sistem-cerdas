import tkinter as tk
from PIL import Image, ImageTk

# File path untuk gambar header
header_files = {
    "default": "header_def.jpg",
    "blue": "header_blue.jpg",
    "green": "header_green.jpg",
    "red": "header_red.jpg",
}

def canvas_menu(header_file):
    root = tk.Tk()
    root.title("Canvas Menu")
    root.geometry("800x600")

    def ubah_header(color):
        root.destroy()
        canvas_menu(header_files[color])

    def kembali_ke_menu_utama():
        root.destroy()
        import menu_utama
        menu_utama.root.mainloop()

    # Header
    try:
        # Load gambar header
        header_image = Image.open(header_file)
        header_original_width, header_original_height = header_image.size

        # Canvas untuk header
        header_canvas = tk.Canvas(root, bg="white", highlightthickness=0, height=100)
        header_canvas.pack(side="top", fill="x")
        
        # Fungsi untuk memperbarui ukuran header
        def update_header(event=None):
            new_width = header_canvas.winfo_width()
            if new_width > 0:
                # Resize gambar agar sesuai dengan lebar baru
                resized_header = header_image.resize((new_width, 100), Image.LANCZOS)
                header_photo = ImageTk.PhotoImage(resized_header)
                header_canvas.image = header_photo  # Simpan referensi agar gambar tidak hilang
                header_canvas.delete("all")  # Hapus elemen sebelumnya
                header_canvas.create_image(0, 0, anchor="nw", image=header_photo)

                # Perbarui area klik untuk setiap kuas
                kuas_width = new_width / 4  # Bagi lebar menjadi 4 bagian
                padding = 50  # Jarak area klik dari tengah setiap kuas
                header_canvas.tag_bind(
                    header_canvas.create_rectangle(kuas_width * 3 + padding, 25, kuas_width * 3 + kuas_width - padding, 75, outline="", fill=""),
                    "<Button-1>",
                    lambda e: ubah_header("default"),
                )
                header_canvas.tag_bind(
                    header_canvas.create_rectangle(kuas_width * 1 + padding, 25, kuas_width * 1 + kuas_width - padding, 75, outline="", fill=""),
                    "<Button-1>",
                    lambda e: ubah_header("blue"),
                )
                header_canvas.tag_bind(
                    header_canvas.create_rectangle(kuas_width * 2 + padding, 25, kuas_width * 2 + kuas_width - padding, 75, outline="", fill=""),
                    "<Button-1>",
                    lambda e: ubah_header("green"),
                )
                header_canvas.tag_bind(
                    header_canvas.create_rectangle(kuas_width * 0 + padding, 25, kuas_width * 0 + kuas_width - padding, 75, outline="", fill=""),
                    "<Button-1>",
                    lambda e: ubah_header("red"),
                )

        header_canvas.bind("<Configure>", update_header)

    except Exception as e:
        print(f"Error memuat header: {e}")
        tk.Label(root, text="Header Tidak Ditemukan").pack(side="top")

    # Canvas untuk melukis
    drawing_canvas = tk.Canvas(root, width=800, height=400, bg="white")
    drawing_canvas.pack(pady=10, fill="both", expand=True)

    def start_draw(event):
        drawing_canvas.old_x, drawing_canvas.old_y = event.x, event.y

    def draw(event):
        x, y = event.x, event.y
        drawing_canvas.create_line(drawing_canvas.old_x, drawing_canvas.old_y, x, y, fill="black", width=2)
        drawing_canvas.old_x, drawing_canvas.old_y = x, y

    def stop_draw(event):
        drawing_canvas.old_x, drawing_canvas.old_y = None, None

    drawing_canvas.old_x, drawing_canvas.old_y = None, None
    drawing_canvas.bind("<Button-1>", start_draw)
    drawing_canvas.bind("<B1-Motion>", draw)
    drawing_canvas.bind("<ButtonRelease-1>", stop_draw)

    # Tombol kembali
    tk.Button(root, text="Kembali", command=kembali_ke_menu_utama).pack(pady=10)

    root.mainloop()
