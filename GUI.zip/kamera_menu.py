import tkinter as tk
from PIL import Image, ImageTk
import cv2
from threading import Thread

# File path untuk gambar header
header_files = {
    "default": "header_def.jpg",
    "blue": "header_blue.jpg",
    "green": "header_green.jpg",
    "red": "header_red.jpg",
}

def kamera_menu(header_file):
    root = tk.Tk()
    root.title("Kamera Menu")
    root.geometry("800x600")

    def ubah_header(color):
        root.destroy()
        kamera_menu(header_files[color])

    def kembali_ke_menu_utama():
        root.destroy()
        import menu_utama
        menu_utama.root.mainloop()

    # Header
    try:
        header_image = Image.open(header_file).resize((800, 100), Image.LANCZOS)
        header_photo = ImageTk.PhotoImage(header_image)
        
        # Canvas untuk header agar bisa diklik
        header_canvas = tk.Canvas(root, width=800, height=100, bg="white", highlightthickness=0)
        header_canvas.pack(side="top", fill="x")
        
        # Tambahkan gambar header ke canvas
        header_canvas.image = header_photo  # Simpan referensi agar gambar tidak hilang
        header_canvas.create_image(0, 0, anchor="nw", image=header_photo)
        
        # Buat area klik untuk kuas (sesuai posisi di header)
        header_canvas.tag_bind(
            header_canvas.create_rectangle(50, 25, 150, 75, outline="", fill=""),
            "<Button-1>",
            lambda e: ubah_header("default")
        )
        header_canvas.tag_bind(
            header_canvas.create_rectangle(200, 25, 300, 75, outline="", fill=""),
            "<Button-1>",
            lambda e: ubah_header("blue")
        )
        header_canvas.tag_bind(
            header_canvas.create_rectangle(350, 25, 450, 75, outline="", fill=""),
            "<Button-1>",
            lambda e: ubah_header("green")
        )
        header_canvas.tag_bind(
            header_canvas.create_rectangle(500, 25, 600, 75, outline="", fill=""),
            "<Button-1>",
            lambda e: ubah_header("red")
        )
    except Exception as e:
        print(f"Error memuat header: {e}")
        tk.Label(root, text="Header Tidak Ditemukan").pack(side="top")

    # Kamera feed
    video_label = tk.Label(root)
    video_label.pack(pady=20)

    def start_camera():
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            video_label.config(text="Kamera tidak terdeteksi", font=("Arial", 18))
            return

        def update_frame():
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frame = cv2.resize(frame, (800, 400))
                img = ImageTk.PhotoImage(Image.fromarray(frame))
                video_label.imgtk = img
                video_label.configure(image=img)
            cap.release()

        Thread(target=update_frame, daemon=True).start()

    start_camera()

    # Tombol kembali
    tk.Button(root, text="Kembali", command=kembali_ke_menu_utama).pack(pady=10)

    root.mainloop()
