import tkinter as tk
from canvas_menu import canvas_menu  # Mengimpor langsung fungsi canvas_menu
from kamera_menu import kamera_menu  # Mengimpor langsung fungsi kamera_menu

def buka_canvas():
    root.destroy()  # Menutup jendela Menu Utama
    canvas_menu("header_def.jpg")  # Membuka Canvas dengan header default

def buka_kamera():
    root.destroy()
    kamera_menu("header_def.jpg")  # Membuka Kamera dengan header default

root = tk.Tk()
root.title("Menu Utama")
root.geometry("800x600")

# Label judul
label_title = tk.Label(root, text="Menu Utama", font=("Arial", 24))
label_title.pack(pady=20)

# Tombol untuk membuka Canvas
btn_canvas = tk.Button(root, text="Canvas", command=buka_canvas, width=20, height=2)
btn_canvas.pack(pady=10)

# Tombol untuk membuka Kamera
btn_kamera = tk.Button(root, text="Kamera", command=buka_kamera, width=20, height=2)
btn_kamera.pack(pady=10)

root.mainloop()
